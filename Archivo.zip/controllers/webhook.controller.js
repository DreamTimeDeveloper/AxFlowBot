// controllers/webhook.controller.js

const { handle: guardarQueja } = require("./queja.controller");
const { handle: agendarCita }  = require("./cita.controller");
const { sendText, sendButton } = require("../services/whatsapp.service");

// Mapa en memoria de estados por número (demo)
const estados = {};

/**
 * Extrae el objeto `message` del body que envía Meta.
 */
function extractMessage(body) {
  const entry  = body.entry?.[0];
  const change = entry?.changes?.[0];
  return change?.value?.messages?.[0] || null;
}

/**
 * GET /webhook
 */
exports.verify = (req, res) => {
  const mode      = req.query["hub.mode"];
  const token     = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];
  const VERIFY   = process.env.VERIFY_TOKEN;

  if (mode === "subscribe" && token === VERIFY) {
    console.log("🟢 Webhook verificado con Meta");
    return res.status(200).send(challenge);
  }
  console.warn("❌ Verificación fallida en webhook");
  return res.sendStatus(403);
};

/**
 * POST /webhook
 */
exports.receive = async (req, res, next) => {
  try {
    const msg = extractMessage(req.body);
    if (!msg) return res.sendStatus(404);

    const from    = msg.from;
    const text    = msg.text?.body;
    const replyId = msg.button?.reply?.id;

    // 1️⃣ Usuario sin estado o sin comando, enviamos menú
    if (!estados[from] && !replyId) {
      estados[from] = null;
      await sendButton(from);
      return res.sendStatus(200);
    }

    // 2️⃣ Botón “ENVIAR_QUEJA”
    if (replyId === "ENVIAR_QUEJA") {
      estados[from] = "PENDIENTE_QUEJA";
      await sendText(from, "✍️ Perfecto, por favor escríbeme tu queja.");
      return res.sendStatus(200);
    }

    // 3️⃣ Botón “AGENDAR_CITA”
    if (replyId === "AGENDAR_CITA") {
      estados[from] = "PENDIENTE_CITA";
      await sendText(from, "📅 Genial, dime día y hora para tu cita.");
      return res.sendStatus(200);
    }

    // 4️⃣ Estado PENDIENTE_QUEJA
    if (estados[from] === "PENDIENTE_QUEJA") {
      await guardarQueja({ from, text });
      await sendText(from, "✅ Tu queja ha sido recibida y guardada. ¡Gracias!");
      estados[from] = null;
      return res.sendStatus(200);
    }

    // 5️⃣ Estado PENDIENTE_CITA
    if (estados[from] === "PENDIENTE_CITA") {
      await agendarCita({ from, text });
      await sendText(from, "✅ Tu cita ha sido agendada. ¡Nos vemos pronto!");
      estados[from] = null;
      return res.sendStatus(200);
    }

    // 6️⃣ Flujo por defecto
    await sendButton(from);
    return res.sendStatus(200);

  } catch (err) {
    console.error("❌ Error en receive webhook:", err);
    next(err);
  }
};
