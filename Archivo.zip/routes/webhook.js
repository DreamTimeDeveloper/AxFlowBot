// routes/webhook.js
const router = require("express").Router();
const { verify, receive } = require("../controllers/webhook.controller");

// Verificación del webhook (Meta envía un challenge por GET)
router.get("/", verify);

// Recepción de mensajes de WhatsApp por POST
router.post("/", receive);

module.exports = router;
